#agriculture product production analsist using Arules 
raw_data = read.csv("FAOSTAT_data.csv")    #raw_data from FAO in 2016
raw_data <- raw_data[,c(2,3,4,6)]

raw_data[,1] = as.character(raw_data[,1])
raw_data[,3] = as.character(raw_data[,3])

flag = grepl(",",raw_data[,3])
temp = regexpr(",",raw_data[,3])
attributes(temp) = NULL

for(i in which(flag)){
  raw_data[i,3] = (substr(raw_data[i,3] , start = 1, stop = temp[i]-1))
}
raw_data[grepl("paper",raw_data[,3]),3] = "Paper"
raw_data[grepl("papers",raw_data[,3]),3] = "Paper"
raw_data[grepl("wood pulp",raw_data[,3]),3] = "Wood pulp"
raw_data[grepl("roundwood",raw_data[,3]),3] = "Roundwood"
raw_data[grepl("charcoal",raw_data[,3]),3] = "Wood fuel"
raw_data[grepl("pellets",raw_data[,3]),3] = "Wood fuel"

str(raw_data)
table(raw_data$Element)
summary(raw_data$Value)

Bad_entry = (raw_data$Value < 1)
cleaned_data = raw_data[!Bad_entry,c(1:3)]
Value = raw_data[!Bad_entry,4]

table(cleaned_data$Element)
summary(Value)
plot(Value[order(Value)])

Value = round(Value^0.1)
summary(Value)
sum(Value)
plot(Value[order(Value)])

# summary(log(raw_data$Value))
# breaking = 5.919
# 
# raw_data$Value[log(raw_data$Value) <  breaking] = 0
# raw_data$Value[log(raw_data$Value) >= breaking] = 1
# table(raw_data$Value)
# raw_data$Value = as.factor(raw_data$Value)
# 
# summary(as.vector(table(raw_data$Area)))
# breaking = 80
# Area = unique(raw_data$Area)
# Acount = as.numeric(table(raw_data$Area))
# Bad_Area = Area[Acount <= breaking]
# raw_data = raw_data[!raw_data$Area %in% Bad_Area,]
# summary(raw_data$Area)

#raw_data$Area <- factor(raw_data$Area)

extend <- function(Cleaned_data, Value){
  loop = length(Value)
  cols = length(Cleaned_data)
  buffer = c()
  for (i in 1:loop){
    clip = Cleaned_data[i,]
    buffer = c(buffer, rep(as.matrix(clip),time = Value[i]))
  }
  return (matrix(buffer,ncol = cols, byrow = T))
}

cleaned_table = extend(cleaned_data,Value)

write.table(cleaned_table,file = "FAOSTAT_data_cleaned.txt", sep = ",", quote = F,
            row.names = F , col.names = F)

# require(arules)
# 
# rule <- apriori(raw_data, 
#                 # min support & confidence
#                 parameter=list( minlen=3, supp=0.1, conf=0.7),  
#                                 appearance = list(default="lhs",
#                                                   rhs=c("Value=0", "Value=1") 
#                 )
# )  
# 
# inspect(rule)
# sort.rule <- sort(rule, by="lift")
# inspect(sort.rule)
# 
# # subset.matrix <- as.matrix(is.subset(x=sort.rule, y=sort.rule))
# # subset.matrix[lower.tri(subset.matrix, diag=T)] <- NA
# # redundant <- colSums(subset.matrix, na.rm=T) >= 1
# # sort.rule <- sort.rule[!redundant]
# # inspect(sort.rule)
# 
# require(arulesViz)
# plot(sort.rule)
# plot(sort.rule, method="graph", control=list(type="items"))
# plot(sort.rule, method="grouped")