rm(list=ls())
cleaned_data = read.table("FAOSTAT_data_cleaned.txt" ,sep = ",")
require(arules)

cleaned_data2 = as(cleaned_data, "transactions")
cleaned_data2
rule <- apriori( cleaned_data2, parameter = list(minlen=2, maxlen = 3, supp=0.1, conf=0.7))

inspect(rule)
sort.rule <- sort(rule, by="lift")
inspect(sort.rule)

# subset.matrix <- as.matrix(is.subset(x=sort.rule, y=sort.rule))
# subset.matrix[lower.tri(subset.matrix, diag=T)] <- NA
# redundant <- colSums(subset.matrix, na.rm=T) >= 1
# sort.rule <- sort.rule[!redundant]
# inspect(sort.rule)

require(arulesViz)
plot(sort.rule)
plot(sort.rule, method="graph", control=list(type="items"))
plot(sort.rule, method="grouped")